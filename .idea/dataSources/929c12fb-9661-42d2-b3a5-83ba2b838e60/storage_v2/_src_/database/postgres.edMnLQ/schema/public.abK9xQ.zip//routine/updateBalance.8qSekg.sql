create function "updateBalance"() returns trigger
    language plpgsql
as
$$BEGIN

update account 
set balance=balance-NEW.price
where NEW.accountNumber=account.accountNumber AND NEW.type='withdrawal'; 

update account 
set balance=balance+NEW.price
where NEW.accountNumber=account.accountNumber AND NEW.type='payment';

RETURN NEW;

END;$$;

alter function "updateBalance"() owner to postgres;

